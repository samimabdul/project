package com.cg.bank.exception;

public class AmountException extends Exception{
	public AmountException() {
			super("Negative or zero amount is not accepted");
	}
}
